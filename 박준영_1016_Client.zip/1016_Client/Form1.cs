﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1016_Client
{
	public partial class Form1 : Form
	{
		WbClient client = new WbClient();
		public Form1()
		{
			InitializeComponent();

			client.ParentInfo(this);
		}

		private void 프로그램종료ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (panel1.BackColor == Color.Red)

				this.Close();
			else if (panel1.BackColor == Color.Blue)
				MessageBox.Show("먼저 연결을 해제해 주십시오...");

		}

		private void 서버연결ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ClientInfo dlg = new ClientInfo();
			if(dlg.ShowDialog() == DialogResult.OK)
			{
				if (client.ClientRun(dlg.Ip, dlg.Port) == true)
				{

					UI.FillDrawing(panel1, Color.Blue);
					UI.LabelState(label1, true);

					String temp = String.Format("[연결] {0} : {1} 성공", client.ServerIp, client.ServerPort /*dlg.Ip, dlg.Port*/);
					UI.LogPrint(listBox1, temp);

					//panel1.BackColor = Color.Blue;
					//label1.Text = "서버연결 성공...";
				}
				else
				{
					String temp = String.Format("[연결]{0} : {1} 실패", client.ServerIp, client.ServerPort /*dlg.Ip, dlg.Port*/);
					UI.LogPrint(listBox1, temp);
				}
			}

		}

		private void 서버연결해제ToolStripMenuItem_Click(object sender, EventArgs e)
		{

			client.ClientStop();
			
			String temp = String.Format("[해제]{0} : {1} 성공", client.ServerIp, client.ServerPort /*dlg.Ip, dlg.Port*/);
			UI.LogPrint(listBox1, temp);

			UI.FillDrawing(panel1, Color.Red);
			UI.LabelState(label1, false);



			//panel1.BackColor = Color.Red;
			//label1.Text = "서버연결해제 성공...";

		}

		private void Button1_Click(object sender, EventArgs e)
		{
			String msg = String.Format("[{0}] : {1}",textBox1.Text, textBox2.Text);
			client.MsgSend(msg);

		}

		public void PrintMsg(string rmsg)
		{
			listBox2.Items.Add(rmsg);
		}
	}
}
