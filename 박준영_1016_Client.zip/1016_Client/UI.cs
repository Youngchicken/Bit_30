﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1016_Client
{
	class UI
	{
		public static void FillDrawing(Control c, Color color)
		{
			c.BackColor = color;
		}

		public static void LabelState(Control c, bool b)
		{
			if (b)
			{
				c.Text = "서버연결 성공...";
				//c.BackColor = Color.Blue;
			}
			else
			{
				c.Text ="서버연결해제 성공...";
				//c.BackColor = Color.Red;

			}
		}

		public static void LogPrint(ListBox l, string msg)
		{
			// msg = [연결]....성공
			msg += "(" + DateTime.Now.ToString() + ")";
			l.Items.Add(msg);
		}

		//public static void MsgPrint(ListBox l, string rcv)
		//{

		//	l.Items.Add(rcv);
		//}
	}
}
