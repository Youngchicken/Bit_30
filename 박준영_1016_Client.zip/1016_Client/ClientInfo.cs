﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1016_Client
{
	public partial class ClientInfo : Form
	{
		public string Ip { get; private set; }
		public int Port { get; private set; }

		public ClientInfo()
		{
			InitializeComponent();
		}

		#region 버튼 핸들러
		private void Button1_Click(object sender, EventArgs e)
		{
			Ip = textBox1.Text;
			Port = int.Parse(textBox2.Text);
			this.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.Close();
		}

		private void Button2_Click(object sender, EventArgs e)
		{
			this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.Close();
		}

		#endregion
	}
}
